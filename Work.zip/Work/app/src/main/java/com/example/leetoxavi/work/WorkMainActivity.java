package com.example.leetoxavi.work;

import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TabHost;

public class WorkMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_main);


        TabHost WorkMainTabHost = (TabHost)findViewById(R.id.work_main_tab_host);
        WorkMainTabHost.setup();

        TabHost.TabSpec WorkMainTapSpec = WorkMainTabHost.newTabSpec("Home");
        WorkMainTapSpec.setContent(R.id.work_main_home);
        WorkMainTapSpec.setIndicator("home");
        WorkMainTabHost.addTab(WorkMainTapSpec);

        WorkMainTapSpec = WorkMainTabHost.newTabSpec("Files");
        WorkMainTapSpec.setContent(R.id.work_main_files);
        WorkMainTapSpec.setIndicator("files");
        WorkMainTabHost.addTab(WorkMainTapSpec);

        WorkMainTapSpec = WorkMainTabHost.newTabSpec("Schedule");
        WorkMainTapSpec.setContent(R.id.work_main_schedule);
        WorkMainTapSpec.setIndicator("Schedule");
        WorkMainTabHost.addTab(WorkMainTapSpec);

        WorkMainTapSpec = WorkMainTabHost.newTabSpec("Messages");
        WorkMainTapSpec.setContent(R.id.work_main_messages);
        WorkMainTapSpec.setIndicator("Messages");
        WorkMainTabHost.addTab(WorkMainTapSpec);

        WorkMainTapSpec = WorkMainTabHost.newTabSpec("Profile");
        WorkMainTapSpec.setContent(R.id.work_main_profile);
        WorkMainTapSpec.setIndicator("Profile");
        WorkMainTabHost.addTab(WorkMainTapSpec);



    }
}
